package DashboardServer

import (
	"github.com/neutralusername/systemge/DashboardHelpers"
	"github.com/neutralusername/systemge/Event"
	"github.com/neutralusername/systemge/Helpers"
	"github.com/neutralusername/systemge/Message"
	"github.com/neutralusername/systemge/helpers"
)

func (server *Server) handleClientCommandRequest(request *Message.Message, connectedClient *connectedClient) error {
	_, err := DashboardHelpers.UnmarshalCommand(request.GetPayload())
	if err != nil {
		return Event.New("Failed to parse command", err)
	}
	resultPayload, err := connectedClient.executeRequest(DashboardHelpers.TOPIC_COMMAND, request.GetPayload())
	if err != nil {
		return Event.New("Failed to execute command", err)
	}
	server.handleWebsocketResponseMessage(resultPayload, connectedClient.connection.GetName())
	return nil
}

func (server *Server) handleClientStartRequest(connectedClient *connectedClient) error {
	resultPayload, err := connectedClient.executeRequest(DashboardHelpers.TOPIC_START, "")
	if err != nil {
		return Event.New("Failed to start client", err)
	}
	err = connectedClient.page.SetCachedStatus(helpers.StringToInt(resultPayload))
	if err != nil {
		// should never happen
		return Event.New("Failed to update status", err)
	}
	server.websocketServer.Multicast(
		server.GetWebsocketClientIdsOnPage(DashboardHelpers.DASHBOARD_CLIENT_NAME),
		Message.NewAsync(
			DashboardHelpers.TOPIC_UPDATE_PAGE_MERGE,
			DashboardHelpers.NewPageUpdate(
				map[string]interface{}{
					DashboardHelpers.CLIENT_FIELD_CLIENTSTATUSES: map[string]int{
						connectedClient.connection.GetName(): Helpers.StringToInt(resultPayload),
					},
				},
				DashboardHelpers.DASHBOARD_CLIENT_NAME,
			).Marshal(),
		),
	)
	server.websocketServer.Multicast(
		server.GetWebsocketClientIdsOnPage(connectedClient.connection.GetName()),
		Message.NewAsync(
			DashboardHelpers.TOPIC_UPDATE_PAGE_MERGE,
			DashboardHelpers.NewPageUpdate(
				map[string]interface{}{
					DashboardHelpers.CLIENT_FIELD_STATUS: helpers.StringToInt(resultPayload),
				},
				connectedClient.connection.GetName(),
			).Marshal(),
		),
	)
	return nil
}

func (server *Server) handleClientStopRequest(connectedClient *connectedClient) error {
	resultPayload, err := connectedClient.executeRequest(DashboardHelpers.TOPIC_STOP, "")
	if err != nil {
		return Event.New("Failed to stop client", err)
	}
	err = connectedClient.page.SetCachedStatus(helpers.StringToInt(resultPayload))
	if err != nil {
		// should never happen
		return Event.New("Failed to update status", err)
	}
	server.websocketServer.Multicast(
		server.GetWebsocketClientIdsOnPage(DashboardHelpers.DASHBOARD_CLIENT_NAME),
		Message.NewAsync(
			DashboardHelpers.TOPIC_UPDATE_PAGE_MERGE,
			DashboardHelpers.NewPageUpdate(
				map[string]interface{}{
					DashboardHelpers.CLIENT_FIELD_CLIENTSTATUSES: map[string]int{
						connectedClient.connection.GetName(): Helpers.StringToInt(resultPayload),
					},
				},
				DashboardHelpers.DASHBOARD_CLIENT_NAME,
			).Marshal(),
		),
	)
	server.websocketServer.Multicast(
		server.GetWebsocketClientIdsOnPage(connectedClient.connection.GetName()),
		Message.NewAsync(
			DashboardHelpers.TOPIC_UPDATE_PAGE_MERGE,
			DashboardHelpers.NewPageUpdate(
				map[string]interface{}{
					DashboardHelpers.CLIENT_FIELD_STATUS: helpers.StringToInt(resultPayload),
				},
				connectedClient.connection.GetName(),
			).Marshal(),
		),
	)
	return nil
}

func (server *Server) handleClientCloseChildRequest(connectedClient *connectedClient, request *Message.Message) error {
	_, err := connectedClient.executeRequest(DashboardHelpers.TOPIC_CLOSE_CHILD, request.GetPayload())
	if err != nil {
		return Event.New("Failed to close child", err)
	}
	systemgeClientChildren := connectedClient.page.GetCachedSystemgeConnectionChildren()
	if systemgeClientChildren == nil {
		// should never happen
		return Event.New("Failed to get systemge connection children", nil)
	}
	delete(systemgeClientChildren, request.GetPayload())
	err = connectedClient.page.SetCachedSystemgeConnectionChildren(systemgeClientChildren)
	if err != nil {
		// should never happen
		return Event.New("Failed to update systemge connection children", err)
	}
	server.websocketServer.Multicast(
		server.GetWebsocketClientIdsOnPage(connectedClient.connection.GetName()),
		Message.NewAsync(
			DashboardHelpers.TOPIC_UPDATE_PAGE_REPLACE,
			DashboardHelpers.NewPageUpdate(
				map[string]interface{}{
					DashboardHelpers.CLIENT_FIELD_SYSTEMGE_CONNECTION_CHILDREN: systemgeClientChildren,
				},
				connectedClient.connection.GetName(),
			).Marshal(),
		),
	)
	return nil
}

func (server *Server) handleClientStartProcessingLoopSequentiallyChildRequest(connectedClient *connectedClient, request *Message.Message) error {
	_, err := connectedClient.executeRequest(DashboardHelpers.TOPIC_START_MESSAGE_HANDLING_LOOP_SEQUENTIALLY_CHILD, request.GetPayload())
	if err != nil {
		return Event.New("Failed to start processing loop", err)
	}
	systemgeClientChildren := connectedClient.page.GetCachedSystemgeConnectionChildren()
	if systemgeClientChildren == nil {
		// should never happen
		return Event.New("Failed to get systemge connection children", nil)
	}
	systemgeClientChildren[request.GetPayload()].IsMessageHandlingLoopStarted = true
	err = connectedClient.page.SetCachedSystemgeConnectionChildren(systemgeClientChildren)
	if err != nil {
		// should never happen
		return Event.New("Failed to update systemge connection children", err)
	}
	server.websocketServer.Multicast(
		server.GetWebsocketClientIdsOnPage(connectedClient.connection.GetName()),
		Message.NewAsync(
			DashboardHelpers.TOPIC_UPDATE_PAGE_REPLACE,
			DashboardHelpers.NewPageUpdate(
				map[string]interface{}{
					DashboardHelpers.CLIENT_FIELD_SYSTEMGE_CONNECTION_CHILDREN: systemgeClientChildren,
				},
				connectedClient.connection.GetName(),
			).Marshal(),
		),
	)
	return nil
}

func (server *Server) handleClientStartProcessingLoopConcurrentlyChildRequest(connectedClient *connectedClient, request *Message.Message) error {
	_, err := connectedClient.executeRequest(DashboardHelpers.TOPIC_START_MESSAGE_HANDLING_LOOP_CONCURRENTLY_CHILD, request.GetPayload())
	if err != nil {
		return Event.New("Failed to start processing loop", err)
	}
	systemgeClientChildren := connectedClient.page.GetCachedSystemgeConnectionChildren()
	if systemgeClientChildren == nil {
		// should never happen
		return Event.New("Failed to get systemge connection children", nil)
	}
	systemgeClientChildren[request.GetPayload()].IsMessageHandlingLoopStarted = true
	err = connectedClient.page.SetCachedSystemgeConnectionChildren(systemgeClientChildren)
	if err != nil {
		// should never happen
		return Event.New("Failed to update systemge connection children", err)
	}
	server.websocketServer.Multicast(
		server.GetWebsocketClientIdsOnPage(connectedClient.connection.GetName()),
		Message.NewAsync(
			DashboardHelpers.TOPIC_UPDATE_PAGE_REPLACE,
			DashboardHelpers.NewPageUpdate(
				map[string]interface{}{
					DashboardHelpers.CLIENT_FIELD_SYSTEMGE_CONNECTION_CHILDREN: systemgeClientChildren,
				},
				connectedClient.connection.GetName(),
			).Marshal(),
		),
	)
	return nil
}

func (server *Server) handleClientStopProcessingLoopChildRequest(connectedClient *connectedClient, request *Message.Message) error {
	_, err := connectedClient.executeRequest(DashboardHelpers.TOPIC_STOP_MESSAGE_HANDLING_LOOP_CHILD, request.GetPayload())
	if err != nil {
		return Event.New("Failed to stop processing loop", err)
	}
	systemgeClientChildren := connectedClient.page.GetCachedSystemgeConnectionChildren()
	if systemgeClientChildren == nil {
		// should never happen
		return Event.New("Failed to get systemge connection children", nil)
	}
	systemgeClientChildren[request.GetPayload()].IsMessageHandlingLoopStarted = false
	err = connectedClient.page.SetCachedSystemgeConnectionChildren(systemgeClientChildren)
	if err != nil {
		// should never happen
		return Event.New("Failed to update systemge connection children", err)
	}
	server.websocketServer.Multicast(
		server.GetWebsocketClientIdsOnPage(connectedClient.connection.GetName()),
		Message.NewAsync(
			DashboardHelpers.TOPIC_UPDATE_PAGE_REPLACE,
			DashboardHelpers.NewPageUpdate(
				map[string]interface{}{
					DashboardHelpers.CLIENT_FIELD_SYSTEMGE_CONNECTION_CHILDREN: systemgeClientChildren,
				},
				connectedClient.connection.GetName(),
			).Marshal(),
		),
	)
	return nil
}

func (server *Server) handleClientHandleNextMessageChildRequest(connectedClient *connectedClient, request *Message.Message) error {
	resultPayload, err := connectedClient.executeRequest(DashboardHelpers.TOPIC_HANDLE_NEXT_MESSAGE_CHILD, request.GetPayload())
	if err != nil {
		return Event.New("Failed to process next message", err)
	}
	handleNextMessageResult, err := DashboardHelpers.UnmarshalHandleNextMessageResult([]byte(resultPayload))
	if err != nil {
		return Event.New("Failed to parse handle next message result", err)
	}
	systemgeClientChildren := connectedClient.page.GetCachedSystemgeConnectionChildren()
	if systemgeClientChildren == nil {
		// should never happen
		return Event.New("Failed to get systemge connection children", nil)
	}
	systemgeClientChildren[request.GetPayload()].UnhandledMessageCount = handleNextMessageResult.UnhandledMessageCount
	err = connectedClient.page.SetCachedSystemgeConnectionChildren(systemgeClientChildren)
	if err != nil {
		// should never happen
		return Event.New("Failed to update systemge connection children", err)
	}
	server.websocketServer.Multicast(
		server.GetWebsocketClientIdsOnPage(connectedClient.connection.GetName()),
		Message.NewAsync(
			DashboardHelpers.TOPIC_UPDATE_PAGE_REPLACE,
			DashboardHelpers.NewPageUpdate(
				map[string]interface{}{
					DashboardHelpers.CLIENT_FIELD_SYSTEMGE_CONNECTION_CHILDREN: systemgeClientChildren,
				},
				connectedClient.connection.GetName(),
			).Marshal(),
		),
	)
	return nil
}

func (server *Server) handleClientMultiSyncRequestRequest(connectedClient *connectedClient, request *Message.Message) error {
	resultPayload, err := connectedClient.executeRequest(DashboardHelpers.TOPIC_MULTI_SYNC_REQUEST, request.GetPayload())
	if err != nil {
		return Event.New("Failed to send multi sync request", err)
	}
	server.handleWebsocketResponseMessage(resultPayload, connectedClient.connection.GetName())
	return nil
}

func (server *Server) handleClientMultiAsyncMessageRequest(connectedClient *connectedClient, request *Message.Message) error {
	_, err := connectedClient.executeRequest(DashboardHelpers.TOPIC_MULTI_ASYNC_MESSAGE, request.GetPayload())
	if err != nil {
		return Event.New("Failed to send multi async message", err)
	}
	server.handleWebsocketResponseMessage("successfully sent multi async message", connectedClient.connection.GetName())
	return nil
}

func (server *Server) handleClientStartProcessingLoopSequentiallyRequest(connectedClient *connectedClient) error {
	_, err := connectedClient.executeRequest(DashboardHelpers.TOPIC_START_MESSAGE_HANDLING_LOOP_SEQUENTIALLY, "")
	if err != nil {
		return Event.New("Failed to start processing loop", err)
	}
	err = connectedClient.page.SetCachedIsProcessingLoopRunning(true)
	if err != nil {
		// should never happen
		return Event.New("Failed to update processing loop status", err)
	}
	server.websocketServer.Multicast(
		server.GetWebsocketClientIdsOnPage(connectedClient.connection.GetName()),
		Message.NewAsync(
			DashboardHelpers.TOPIC_UPDATE_PAGE_REPLACE,
			DashboardHelpers.NewPageUpdate(
				map[string]interface{}{
					DashboardHelpers.CLIENT_FIELD_IS_MESSAGE_HANDLING_LOOP_STARTED: true,
				},
				connectedClient.connection.GetName(),
			).Marshal(),
		),
	)
	return nil
}

func (server *Server) handleClientStartProcessingLoopConcurrentlyRequest(connectedClient *connectedClient) error {
	_, err := connectedClient.executeRequest(DashboardHelpers.TOPIC_START_MESSAGE_HANDLING_LOOP_CONCURRENTLY, "")
	if err != nil {
		return Event.New("Failed to start processing loop", err)
	}
	err = connectedClient.page.SetCachedIsProcessingLoopRunning(true)
	if err != nil {
		// should never happen
		return Event.New("Failed to update processing loop status", err)
	}
	server.websocketServer.Multicast(
		server.GetWebsocketClientIdsOnPage(connectedClient.connection.GetName()),
		Message.NewAsync(
			DashboardHelpers.TOPIC_UPDATE_PAGE_REPLACE,
			DashboardHelpers.NewPageUpdate(
				map[string]interface{}{
					DashboardHelpers.CLIENT_FIELD_IS_MESSAGE_HANDLING_LOOP_STARTED: true,
				},
				connectedClient.connection.GetName(),
			).Marshal(),
		),
	)
	return nil
}

func (server *Server) handleClientStopProcessingLoopRequest(connectedClient *connectedClient) error {
	_, err := connectedClient.executeRequest(DashboardHelpers.TOPIC_STOP_MESSAGE_HANDLING_LOOP, "")
	if err != nil {
		return Event.New("Failed to stop processing loop", err)
	}
	err = connectedClient.page.SetCachedIsProcessingLoopRunning(false)
	if err != nil {
		// should never happen
		return Event.New("Failed to update processing loop status", err)
	}
	server.websocketServer.Multicast(
		server.GetWebsocketClientIdsOnPage(connectedClient.connection.GetName()),
		Message.NewAsync(
			DashboardHelpers.TOPIC_UPDATE_PAGE_REPLACE,
			DashboardHelpers.NewPageUpdate(
				map[string]interface{}{
					DashboardHelpers.CLIENT_FIELD_IS_MESSAGE_HANDLING_LOOP_STARTED: false,
				},
				connectedClient.connection.GetName(),
			).Marshal(),
		),
	)
	return nil
}

func (server *Server) handleClientHandleNextMessageRequest(connectedClient *connectedClient) error {
	resultPayload, err := connectedClient.executeRequest(DashboardHelpers.TOPIC_HANDLE_NEXT_MESSAGE, "")
	if err != nil {
		return Event.New("Failed to process next message", err)
	}
	handleNextMessageResult, err := DashboardHelpers.UnmarshalHandleNextMessageResult([]byte(resultPayload))
	if err != nil {
		return Event.New("Failed to parse handle next message result", err)
	}

	err = connectedClient.page.SetCachedUnprocessedMessageCount(handleNextMessageResult.UnhandledMessageCount)
	if err != nil {
		// should never happen
		return Event.New("Failed to update processing loop status", err)
	}
	server.websocketServer.Multicast(
		server.GetWebsocketClientIdsOnPage(connectedClient.connection.GetName()),
		Message.NewAsync(
			DashboardHelpers.TOPIC_UPDATE_PAGE_REPLACE,
			DashboardHelpers.NewPageUpdate(
				map[string]interface{}{
					DashboardHelpers.CLIENT_FIELD_UNHANDLED_MESSAGE_COUNT: helpers.StringToUint32(resultPayload),
				},
				connectedClient.connection.GetName(),
			).Marshal(),
		),
	)
	server.handleWebsocketResponseMessage(resultPayload, connectedClient.connection.GetName())
	return nil
}

func (server *Server) handleClientSyncRequestRequest(connectedClient *connectedClient, request *Message.Message) error {
	resultPayload, err := connectedClient.executeRequest(DashboardHelpers.TOPIC_SYNC_REQUEST, request.GetPayload())
	if err != nil {
		return Event.New("Failed to send sync request", err)
	}
	server.handleWebsocketResponseMessage(resultPayload, connectedClient.connection.GetName())
	return nil
}

func (server *Server) handleClientAsyncMessageRequest(connectedClient *connectedClient, request *Message.Message) error {
	_, err := connectedClient.executeRequest(DashboardHelpers.TOPIC_ASYNC_MESSAGE, request.GetPayload())
	if err != nil {
		return Event.New("Failed to send async message", err)
	}
	server.handleWebsocketResponseMessage("successfully sent async message", connectedClient.connection.GetName())
	return nil
}
