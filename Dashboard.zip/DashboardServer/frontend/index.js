import {
    root,
} from "./root/root.js"

ReactDOM.render(
    React.createElement(root), document.body
);