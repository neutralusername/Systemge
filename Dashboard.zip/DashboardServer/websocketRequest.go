package DashboardServer

import (
	"runtime"

	"github.com/neutralusername/systemge/DashboardHelpers"
	"github.com/neutralusername/systemge/Event"
	"github.com/neutralusername/systemge/Message"
	"github.com/neutralusername/systemge/WebsocketServer"
)

func (server *Server) pageRequestHandler(websocketClient *WebsocketServer.WebsocketConnection, message *Message.Message) error {
	server.mutex.RLock()
	currentPage := server.websocketClientLocations[websocketClient]
	connectedClient := server.connectedClients[currentPage]
	server.mutex.RUnlock()

	request, err := Message.Deserialize([]byte(message.GetPayload()), websocketClient.GetId())
	if err != nil {
		return Event.New("Failed to deserialize request", err)
	}

	if request.GetTopic() == DashboardHelpers.TOPIC_DELETE_CACHED_RESPONSE_MESSAGE {
		responseId := request.GetPayload()
		server.mutex.Lock()
		if _, ok := server.responseMessageCache[responseId]; ok {
			delete(server.responseMessageCache, responseId)
			for i, responseMessage := range server.responseMessageCacheOrder {
				if responseMessage.Id == responseId {
					server.responseMessageCacheOrder = append(server.responseMessageCacheOrder[:i], server.responseMessageCacheOrder[i+1:]...)
					break
				}
			}
			server.mutex.Unlock()
			server.websocketServer.Broadcast(
				Message.NewAsync(
					DashboardHelpers.TOPIC_DELETE_CACHED_RESPONSE_MESSAGE,
					responseId,
				),
			)
			return nil
		} else {
			server.mutex.Unlock()
			return Event.New("Cached response message not found", nil)
		}
	} else {
		switch currentPage {
		case "":
			return Event.New("No location", nil)
		case DashboardHelpers.DASHBOARD_CLIENT_NAME:
			return server.handleDashboardRequest(request)
		default:
			if connectedClient == nil {
				// should never happen
				return Event.New("Client not found", nil)
			}
			switch connectedClient.page.Type {
			case DashboardHelpers.CLIENT_TYPE_COMMAND:
				return server.handleCommandClientRequest(request, connectedClient)
			case DashboardHelpers.CLIENT_TYPE_CUSTOMSERVICE:
				return server.handleCustomServiceClientRequest(request, connectedClient)
			case DashboardHelpers.CLIENT_TYPE_SYSTEMGECONNECTION:
				return server.handleSystemgeConnectionClientRequest(request, connectedClient)
			case DashboardHelpers.CLIENT_TYPE_SYSTEMGESERVER:
				return server.handleSystemgeServerClientRequest(request, connectedClient)
			default:
				// should never happen
				return Event.New("Unknown client type", nil)
			}
		}
	}
}

func (server *Server) handleDashboardRequest(request *Message.Message) error {
	switch request.GetTopic() {
	case DashboardHelpers.TOPIC_COMMAND:
		command, err := DashboardHelpers.UnmarshalCommand(request.GetPayload())
		if err != nil {
			return Event.New("Failed to parse command", err)
		}
		commandHandler, _ := server.dashboardCommandHandlers.Get(command.Command)
		if commandHandler == nil {
			return Event.New("Command not found", nil)
		}
		resultPayload, err := commandHandler(command.Args)
		if err != nil {
			return Event.New("Failed to execute command", err)
		}
		server.handleWebsocketResponseMessage(resultPayload, DashboardHelpers.DASHBOARD_CLIENT_NAME)
		return nil
	case DashboardHelpers.TOPIC_COLLECT_GARBAGE:
		runtime.GC()
		server.handleWebsocketResponseMessage("Garbage collected", DashboardHelpers.DASHBOARD_CLIENT_NAME)
		return nil
	case DashboardHelpers.TOPIC_STOP:
		clientName := request.GetPayload()
		if clientName == "" {
			return Event.New("No client name", nil)
		}
		server.mutex.RLock()
		connectedClient, ok := server.connectedClients[clientName]
		server.mutex.RUnlock()
		if !ok {
			return Event.New("Client not found", nil)
		}
		if err := server.handleClientStopRequest(connectedClient); err != nil {
			return Event.New("Failed to stop client", err)
		}
		server.handleWebsocketResponseMessage("success", DashboardHelpers.DASHBOARD_CLIENT_NAME)
		return nil
	case DashboardHelpers.TOPIC_START:
		clientName := request.GetPayload()
		if clientName == "" {
			return Event.New("No client name", nil)
		}
		server.mutex.RLock()
		connectedClient, ok := server.connectedClients[clientName]
		server.mutex.RUnlock()
		if !ok {
			return Event.New("Client not found", nil)
		}
		if err := server.handleClientStartRequest(connectedClient); err != nil {
			return Event.New("Failed to start client", err)
		}
		server.handleWebsocketResponseMessage("success", DashboardHelpers.DASHBOARD_CLIENT_NAME)
		return nil
	case DashboardHelpers.TOPIC_SUDOKU:
		err := server.Stop()
		if err != nil {
			return Event.New("Failed to stop server", err)
		}
		return nil
	default:
		return Event.New("Unknown topic", nil)
	}
}

func (server *Server) handleCommandClientRequest(request *Message.Message, connectedClient *connectedClient) error {
	switch request.GetTopic() {
	case DashboardHelpers.TOPIC_COMMAND:
		return server.handleClientCommandRequest(request, connectedClient)
	case DashboardHelpers.TOPIC_SUDOKU:
		return connectedClient.connection.Close()
	default:
		return Event.New("Unknown topic", nil)
	}
}

func (server *Server) handleCustomServiceClientRequest(request *Message.Message, connectedClient *connectedClient) error {
	switch request.GetTopic() {
	case DashboardHelpers.TOPIC_COMMAND:
		return server.handleClientCommandRequest(request, connectedClient)
	case DashboardHelpers.TOPIC_START:
		return server.handleClientStartRequest(connectedClient)
	case DashboardHelpers.TOPIC_STOP:
		return server.handleClientStopRequest(connectedClient)
	case DashboardHelpers.TOPIC_SUDOKU:
		return connectedClient.connection.Close()
	default:
		return Event.New("Unknown topic", nil)
	}
}

func (server *Server) handleSystemgeConnectionClientRequest(request *Message.Message, connectedClient *connectedClient) error {
	switch request.GetTopic() {
	case DashboardHelpers.TOPIC_COMMAND:
		return server.handleClientCommandRequest(request, connectedClient)
	case DashboardHelpers.TOPIC_STOP:
		return server.handleClientStopRequest(connectedClient)
	case DashboardHelpers.TOPIC_START_MESSAGE_HANDLING_LOOP_SEQUENTIALLY:
		return server.handleClientStartProcessingLoopSequentiallyRequest(connectedClient)
	case DashboardHelpers.TOPIC_START_MESSAGE_HANDLING_LOOP_CONCURRENTLY:
		return server.handleClientStartProcessingLoopConcurrentlyRequest(connectedClient)
	case DashboardHelpers.TOPIC_STOP_MESSAGE_HANDLING_LOOP:
		return server.handleClientStopProcessingLoopRequest(connectedClient)
	case DashboardHelpers.TOPIC_HANDLE_NEXT_MESSAGE:
		return server.handleClientHandleNextMessageRequest(connectedClient)
	case DashboardHelpers.TOPIC_SYNC_REQUEST:
		return server.handleClientSyncRequestRequest(connectedClient, request)
	case DashboardHelpers.TOPIC_ASYNC_MESSAGE:
		return server.handleClientAsyncMessageRequest(connectedClient, request)
	case DashboardHelpers.TOPIC_SUDOKU:
		return connectedClient.connection.Close()
	default:
		return Event.New("Unknown topic", nil)
	}
}

func (server *Server) handleSystemgeServerClientRequest(request *Message.Message, connectedClient *connectedClient) error {
	switch request.GetTopic() {
	case DashboardHelpers.TOPIC_COMMAND:
		return server.handleClientCommandRequest(request, connectedClient)
	case DashboardHelpers.TOPIC_START:
		return server.handleClientStartRequest(connectedClient)
	case DashboardHelpers.TOPIC_STOP:
		return server.handleClientStopRequest(connectedClient)
	case DashboardHelpers.TOPIC_CLOSE_CHILD:
		return server.handleClientCloseChildRequest(connectedClient, request)
	case DashboardHelpers.TOPIC_START_MESSAGE_HANDLING_LOOP_SEQUENTIALLY_CHILD:
		return server.handleClientStartProcessingLoopSequentiallyChildRequest(connectedClient, request)
	case DashboardHelpers.TOPIC_START_MESSAGE_HANDLING_LOOP_CONCURRENTLY_CHILD:
		return server.handleClientStartProcessingLoopConcurrentlyChildRequest(connectedClient, request)
	case DashboardHelpers.TOPIC_STOP_MESSAGE_HANDLING_LOOP_CHILD:
		return server.handleClientStopProcessingLoopChildRequest(connectedClient, request)
	case DashboardHelpers.TOPIC_HANDLE_NEXT_MESSAGE_CHILD:
		return server.handleClientHandleNextMessageChildRequest(connectedClient, request)
	case DashboardHelpers.TOPIC_MULTI_SYNC_REQUEST:
		return server.handleClientMultiSyncRequestRequest(connectedClient, request)
	case DashboardHelpers.TOPIC_MULTI_ASYNC_MESSAGE:
		return server.handleClientMultiAsyncMessageRequest(connectedClient, request)
	case DashboardHelpers.TOPIC_SUDOKU:
		return connectedClient.connection.Close()
	default:
		return Event.New("Unknown topic", nil)
	}
}
